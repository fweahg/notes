#!/bin/bash
cd ${0%/*}
echo stop with ctrl-c
node --watch tcp-echo.js
