#!/bin/bash
cd ${0%/*}
telnet localhost 1234
