const net = require('node:net');

const server = net.createServer();
let socks = new Array();

server.on('connection', function(socket) {
   socket.setEncoding('utf8');
   const id = socket.remotePort;
   
   socks.push({socky: id, socku: socket});
   
   console.log('client connected ', socks.length);
   socket.write(`hello ${id}\nspecial command:hello bye\n`);
   
   function broadcast(msg){
       for (sock of socks){
           sock.socku.write(msg);
       };
   };
   
   socket.on('end', ()=>{
        let idx = socks.findIndex(client => client.socky === id);
        socks.splice(idx, 1);
        console.log('client disconnected : ', id);
        //process.exit(0);
   });
   
   socket.on('data', function(chunk) {
       switch(chunk) {
           case 'bye\r\n':
            broadcast(`${id} : bye\n`);
            socket.end();
            break;
            
           case 'hello\r\n':
            socket.write('common to the world ');
           
           default:
            broadcast(`${id} : ${chunk}`);
            console.log(`${id} : ${chunk}`);
       }
   });
   
});

server.on('error', (err)=>{
    console.log(err);
});

server.listen(1234, ()=>{
    console.log('server listening ', server.address());
});
